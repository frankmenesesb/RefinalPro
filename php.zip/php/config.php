<?php
    $datos = array(
        '0' => 'localhost',
        '1' => 'refinal',
        '2' => 'refin@l2015',
        '3' => 'refinalapp');
?>