<?php
    $datos = array(
        '0' => 'localhost:3388',
        '1' => 'root',
        '2' => '',
        '3' => 'pspprueba');
?>